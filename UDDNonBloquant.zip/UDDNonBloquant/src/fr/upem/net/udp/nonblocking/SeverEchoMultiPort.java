package fr.upem.net.udp.nonblocking;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.logging.Logger;
import java.util.stream.IntStream;

public class SeverEchoMultiPort {
    private static class Context{
        private final ByteBuffer buffer = ByteBuffer.allocateDirect(BUFFER_SIZE);
        private SocketAddress sender = null;


    }
    private static final Logger logger = Logger.getLogger(ServerEcho.class.getName());
    private static final int BUFFER_SIZE = 1024;
    private final Selector selector;


    public SeverEchoMultiPort(int portmin, int portmax) throws IOException {
        // Saves ports and open selector
        selector = Selector.open();
        // For all ports: Open, bind and set non-blocking DatagramChannel, and register it in the Selector
        for(var i = portmin; i <= portmax; i++)
        {
            var dc = DatagramChannel.open();
            dc.bind(new InetSocketAddress(i));
            dc.configureBlocking(false);
            dc.register(selector, SelectionKey.OP_READ, new Context());
        }
    }

    public void serve(String[] args) throws IOException {
        logger.info("ServerEchoMultiPort starded on ports in " + Arrays.toString(args));
        while (!Thread.interrupted()) {
            selector.select(this::treatKey);
        }
    }

    private void treatKey(SelectionKey key) {
        try {
            if (key.isValid() && key.isWritable()) {
                doWrite(key);
            }
            if (key.isValid() && key.isReadable()) {
                doRead(key);
            }
        } catch (IOException e) {
            logger.warning("Can't send or recieve message.");
            return;
        }
    }

    private void doRead(SelectionKey key) throws IOException {
        var context = (Context) key.attachment();
        context.buffer.clear();
        var dc = (DatagramChannel) key.channel();
        context.sender = dc.receive(context.buffer);
        if(context.sender == null){
            logger.warning("packet not read");
            return;
        }
        context.buffer.flip();
        logger.info("packet read : " + StandardCharsets.US_ASCII.decode(context.buffer) + " from :" + context.sender);
        context.buffer.flip();
        key.interestOps(SelectionKey.OP_WRITE);
    }

    private void doWrite(SelectionKey key) throws IOException {
        var dc = (DatagramChannel) key.channel();
        Context context = (Context) key.attachment();
        dc.send(context.buffer, context.sender);
        if(context.buffer.hasRemaining()){
            logger.warning("Packet not send");
            return;
        }
        context.buffer.flip();
        logger.info("packet send : " + StandardCharsets.US_ASCII.decode(context.buffer) + " to :" + context.sender );
        key.interestOps(SelectionKey.OP_READ);
    }

    public static void usage() {
        System.out.println("Usage : ServerEchoMultiPort portmin portmax ");
    }

    public static void main(String[] args) throws IOException {
        if (args.length != 2 || Integer.parseInt(args[0]) > Integer.parseInt(args[1])) {
            usage();
            return;
        }
        new SeverEchoMultiPort(Integer.parseInt(args[0]), Integer.parseInt(args[1])).serve(args);
    }

}
